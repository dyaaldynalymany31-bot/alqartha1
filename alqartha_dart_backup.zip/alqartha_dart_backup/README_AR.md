# تطبيق دنيا السعيد - Donia Al-Saeed Kitchen Designs

## 📱 نظرة عامة

تطبيق Flutter متكامل لتصاميم مطابخ الألمنيوم المصرية، يدعم Android و Windows Desktop.

---

## 🚀 البدء السريع

### 1. افتح المشروع في VS Code
2. افتح Terminal (`Ctrl + ~`)
3. نفذ:

```bash
flutter clean
flutter pub get
flutter config --enable-windows-desktop
flutter run -d windows
```

📖 **للتفاصيل الكاملة، اقرأ: `START_HERE.md`**

---

## ✨ الميزات الرئيسية

### 🔐 المصادقة
- تسجيل الدخول والتسجيل
- دعم Google و Apple Sign-In (UI)
- إدارة الجلسات

### 🏠 الصفحة الرئيسية
- عروض خاصة
- خدمات 3D و AR (UI)
- أحدث المجموعات

### 🎨 معرض التصاميم
- عرض جميع التصاميم
- فلترة وبحث
- تفاصيل التصميم
- خيارات الألوان

### 📦 إدارة الطلبات
- تتبع حالة الطلبات
- طلب تصميم مخصص (3 خطوات)
- كشف العميل والمدفوعات
- سجل المعاملات

### 👤 الملف الشخصي
- معلومات المستخدم
- نظام نقاط الولاء
- لوحة التحكم
- الإعدادات

### 🎯 ميزات متقدمة
- عارض 3D للمطبخ (UI)
- تجربة AR (UI)
- قياسات متقدمة (UI)

---

## 🛠️ التقنيات المستخدمة

- **Framework**: Flutter 3.0+
- **State Management**: Provider, GetX
- **UI Components**: Google Fonts, Cached Network Image
- **Storage**: Shared Preferences
- **Network**: Dio, HTTP
- **Navigation**: GetX Router
- **Language**: العربية (RTL كامل)

---

## 📂 هيكل المشروع

```
lib/
├── core/
│   ├── constants/      # الثوابت
│   ├── routes/         # المسارات
│   ├── services/       # الخدمات
│   ├── theme/          # الثيم
│   └── utils/          # أدوات مساعدة
├── features/
│   ├── auth/           # المصادقة
│   ├── home/           # الرئيسية
│   ├── designs/        # التصاميم
│   ├── orders/         # الطلبات
│   ├── profile/        # الملف الشخصي
│   ├── 3d/             # عرض 3D
│   ├── ar/             # الواقع المعزز
│   └── measurements/   # القياسات
└── main.dart
```

---

## 📝 الشاشات المتوفرة

✅ Splash Screen  
✅ Login & Sign Up  
✅ Home Page  
✅ Designs Gallery  
✅ Design Details  
✅ Orders Tracking  
✅ Custom Order Request  
✅ Customer Statement  
✅ User Profile  
✅ Contact Us  
✅ About App  
✅ 3D Kitchen Viewer (UI)  
✅ AR Try-On (UI)  
✅ Advanced Measurements (UI)  

---

## 🎯 الخطوات التالية للتطوير

1. **ربط API حقيقي**
   - عدّل `AppConstants.baseUrl`
   - نفّذ API calls في Services

2. **إضافة الصور الحقيقية**
   - ضع الصور في `assets/images/`
   - استبدل placeholder URLs

3. **تفعيل ميزات 3D/AR**
   - أضف مكتبات 3D حقيقية
   - نفّذ ARCore/ARKit

4. **إضافة المزيد من الميزات**
   - نظام الدفع
   - الإشعارات
   - الدردشة
   - التقييمات

---

## 🔧 المشاكل الشائعة

### "flutter_gl not found"
✅ تم حلها - المكتبة محذوفة

### "No devices found"
```bash
flutter config --enable-windows-desktop
flutter run -d windows
```

### "Android v1 embedding"
✅ تم حلها - ملفات Android محدثة

---

## 📚 الملفات التوثيقية

- `START_HERE.md` - ابدأ من هنا
- `COMPLETE_SETUP_GUIDE.md` - دليل الإعداد الكامل
- `HOW_TO_RUN.md` - كيفية التشغيل
- `FIX_PUBSPEC_ERROR.md` - حل مشاكل pubspec

---

## 📞 معلومات الاتصال

- **البريد**: info@donia-al-saeed.com
- **الهاتف**: +20 123 456 7890
- **العنوان**: القاهرة الجديدة، مصر

---

## 📄 الترخيص

هذا المشروع خاص بشركة دنيا السعيد.

---

## 🎉 المشروع جاهز!

المشروع مكتمل ويعمل بشكل كامل. للبدء، اتبع التعليمات في `START_HERE.md`

**تم التطوير بـ ❤️ باستخدام Flutter**
