# دليل تشغيل المشروع في VS Code و Android Studio

## 📋 المتطلبات الأساسية

قبل البدء، تأكد من تثبيت:
- ✅ Flutter SDK (الإصدار 3.0.0 أو أحدث)
- ✅ Dart SDK
- ✅ VS Code أو Android Studio
- ✅ Android SDK (للتطوير على Android)
- ✅ Git (اختياري)

---

## 🚀 الطريقة 1: تشغيل في VS Code

### الخطوة 1: فتح المشروع
1. افتح **VS Code**
2. اضغط `Ctrl + Shift + P` (أو `Cmd + Shift + P` على Mac)
3. اكتب `Flutter: New Project` أو اختر `File > Open Folder`
4. اختر مجلد المشروع: `C:\Users\nathe\OneDrive\Desktop\واجهات فلاتر للمحل`

### الخطوة 2: تثبيت الإضافات المطلوبة
في VS Code، تأكد من تثبيت:
- **Flutter** (من Dart Code)
- **Dart** (من Dart Code)

**كيفية التثبيت:**
1. اضغط على أيقونة Extensions (أو `Ctrl + Shift + X`)
2. ابحث عن "Flutter"
3. اضغط Install على إضافة Flutter الرسمية

### الخطوة 3: تثبيت التبعيات
1. افتح Terminal في VS Code (`Ctrl + ~` أو `Terminal > New Terminal`)
2. نفذ الأمر:
```bash
flutter pub get
```

### الخطوة 4: التحقق من الإعداد
```bash
flutter doctor
```
تأكد من أن جميع العناصر تظهر علامة ✅

### الخطوة 5: تشغيل التطبيق

#### على Android:
1. تأكد من وجود جهاز Android متصل أو Emulator يعمل
2. اضغط `F5` أو `Ctrl + F5`
3. أو من Terminal:
```bash
flutter run
```

#### على Windows:
```bash
flutter run -d windows
```

#### اختيار الجهاز:
```bash
flutter devices
```
ثم اختر الجهاز:
```bash
flutter run -d <device-id>
```

---

## 🤖 الطريقة 2: تشغيل في Android Studio

### الخطوة 1: فتح المشروع
1. افتح **Android Studio**
2. اختر `File > Open`
3. اختر مجلد المشروع: `C:\Users\nathe\OneDrive\Desktop\واجهات فلاتر للمحل`
4. اضغط OK

### الخطوة 2: تثبيت Flutter Plugin
1. اذهب إلى `File > Settings` (أو `Android Studio > Preferences` على Mac)
2. اختر `Plugins`
3. ابحث عن "Flutter"
4. اضغط Install (سيقوم بتثبيت Dart تلقائياً)
5. أعد تشغيل Android Studio

### الخطوة 3: تثبيت التبعيات
1. افتح Terminal في Android Studio (أسفل الشاشة)
2. نفذ:
```bash
flutter pub get
```

### الخطوة 4: إعداد Android Emulator (إذا لم يكن موجود)
1. اضغط على أيقونة Device Manager (أو `Tools > Device Manager`)
2. اضغط `Create Device`
3. اختر جهاز (مثلاً Pixel 5)
4. اختر نظام (مثلاً Android 11)
5. اضغط Finish

### الخطوة 5: تشغيل التطبيق
1. اختر جهاز من القائمة المنسدلة (أعلى الشاشة)
2. اضغط على زر Run (▶️) أو `Shift + F10`
3. أو من Terminal:
```bash
flutter run
```

---

## 🔧 حل المشاكل الشائعة

### مشكلة: "Flutter command not found"
**الحل:**
1. أضف Flutter إلى PATH:
   - Windows: أضف مسار Flutter إلى System Environment Variables
   - مثال: `C:\src\flutter\bin`
2. أعد تشغيل VS Code/Android Studio

### مشكلة: "No devices found"
**الحل:**
```bash
# تحقق من الأجهزة المتاحة
flutter devices

# لـ Android: تأكد من تفعيل USB Debugging
# لـ Windows: تأكد من تفعيل Windows Desktop
flutter config --enable-windows-desktop
```

### مشكلة: "pub get failed"
**الحل:**
```bash
# امسح الكاش
flutter clean
flutter pub get
```

### مشكلة: "Gradle build failed"
**الحل:**
1. افتح `android/gradle/wrapper/gradle-wrapper.properties`
2. تأكد من وجود Gradle version صحيحة
3. نفذ:
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
```

### مشكلة: الخطوط العربية لا تظهر
**الحل:**
1. تأكد من وجود الخطوط في `assets/fonts/`
2. تحقق من `pubspec.yaml` أن المسارات صحيحة
3. أعد تشغيل التطبيق

---

## 📱 تشغيل على أجهزة مختلفة

### Android Emulator:
```bash
flutter run
```

### Android Device (USB):
1. فعّل USB Debugging في إعدادات الهاتف
2. وصّل الهاتف بالكمبيوتر
3. نفذ:
```bash
flutter devices
flutter run
```

### Windows Desktop:
```bash
flutter config --enable-windows-desktop
flutter run -d windows
```

---

## 🎯 نصائح مهمة

1. **Hot Reload**: اضغط `r` في Terminal لإعادة تحميل سريع
2. **Hot Restart**: اضغط `R` لإعادة تشغيل كاملة
3. **Stop**: اضغط `q` لإيقاف التطبيق
4. **Debug Mode**: استخدم `F5` في VS Code للتصحيح
5. **Release Mode**: 
   ```bash
   flutter run --release
   ```

---

## 📝 أوامر مفيدة

```bash
# عرض الأجهزة المتاحة
flutter devices

# تنظيف المشروع
flutter clean

# تثبيت التبعيات
flutter pub get

# تحديث التبعيات
flutter pub upgrade

# بناء APK
flutter build apk

# بناء App Bundle
flutter build appbundle

# بناء Windows
flutter build windows

# فحص الإعدادات
flutter doctor -v
```

---

## ✅ التحقق من نجاح التشغيل

عندما يعمل التطبيق بنجاح، سترى:
- ✅ شاشة Splash Screen (أزرق مع أيقونة المطبخ)
- ✅ شاشة Login بعد 3 ثوانٍ
- ✅ يمكنك تسجيل الدخول بأي بيانات

---

## 🆘 إذا واجهت مشاكل

1. تحقق من `flutter doctor -v`
2. تأكد من تحديث Flutter: `flutter upgrade`
3. راجع ملف `debug.log` في مجلد المشروع
4. امسح الكاش: `flutter clean && flutter pub get`

---

**جاهز للبدء! 🚀**
