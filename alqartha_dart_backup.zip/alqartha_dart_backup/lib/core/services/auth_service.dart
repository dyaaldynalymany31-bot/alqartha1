import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../constants/app_constants.dart';
import 'storage_service.dart';
import '../../features/auth/domain/models/user_model.dart';

class AuthService extends GetxController {
  UserModel? _currentUser;
  bool _isAuthenticated = false;

  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _isAuthenticated;

  @override
  void onInit() {
    super.onInit();
    _loadUserFromStorage();
  }

  Future<void> _loadUserFromStorage() async {
    final token = StorageService.getString(AppConstants.tokenKey);
    if (token != null && token.isNotEmpty) {
      _isAuthenticated = true;
      // يمكن تحميل بيانات المستخدم من Storage
    }
  }

  Future<bool> login(String emailOrPhone, String password) async {
    try {
      // محاكاة تسجيل الدخول - يمكن استبدالها بـ API حقيقي
      await Future.delayed(const Duration(seconds: 1));
      
      // في التطبيق الحقيقي، هنا سيكون استدعاء API
      _currentUser = UserModel(
        id: '1',
        name: 'أحمد السعيد',
        email: emailOrPhone,
        phone: emailOrPhone,
        loyaltyPoints: 1250,
        loyaltyTier: 'Gold',
      );
      
      _isAuthenticated = true;
      await StorageService.saveString(AppConstants.tokenKey, 'mock_token_123');
      await StorageService.saveString(AppConstants.userKey, _currentUser!.toJson().toString());
      
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> signUp({
    required String fullName,
    required String emailOrPhone,
    required String password,
  }) async {
    try {
      // محاكاة التسجيل - يمكن استبدالها بـ API حقيقي
      await Future.delayed(const Duration(seconds: 1));
      
      _currentUser = UserModel(
        id: '1',
        name: fullName,
        email: emailOrPhone,
        phone: emailOrPhone,
        loyaltyPoints: 0,
        loyaltyTier: 'Bronze',
      );
      
      _isAuthenticated = true;
      await StorageService.saveString(AppConstants.tokenKey, 'mock_token_123');
      await StorageService.saveString(AppConstants.userKey, _currentUser!.toJson().toString());
      
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> logout() async {
    _currentUser = null;
    _isAuthenticated = false;
    await StorageService.remove(AppConstants.tokenKey);
    await StorageService.remove(AppConstants.userKey);
  }

  Future<bool> forgotPassword(String emailOrPhone) async {
    try {
      // محاكاة إعادة تعيين كلمة المرور
      await Future.delayed(const Duration(seconds: 1));
      return true;
    } catch (e) {
      return false;
    }
  }
}
