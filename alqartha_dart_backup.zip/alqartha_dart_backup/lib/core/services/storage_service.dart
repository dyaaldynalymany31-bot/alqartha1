import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Save String
  static Future<bool> saveString(String key, String value) async {
    return await _prefs?.setString(key, value) ?? false;
  }

  // Get String
  static String? getString(String key) {
    return _prefs?.getString(key);
  }

  // Save Int
  static Future<bool> saveInt(String key, int value) async {
    return await _prefs?.setInt(key, value) ?? false;
  }

  // Get Int
  static int? getInt(String key) {
    return _prefs?.getInt(key);
  }

  // Save Bool
  static Future<bool> saveBool(String key, bool value) async {
    return await _prefs?.setBool(key, value) ?? false;
  }

  // Get Bool
  static bool? getBool(String key) {
    return _prefs?.getBool(key);
  }

  // Remove
  static Future<bool> remove(String key) async {
    return await _prefs?.remove(key) ?? false;
  }

  // Clear All
  static Future<bool> clear() async {
    return await _prefs?.clear() ?? false;
  }
}
