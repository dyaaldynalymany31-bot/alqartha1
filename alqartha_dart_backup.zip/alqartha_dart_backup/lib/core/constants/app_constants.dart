class AppConstants {
  // معلومات التطبيق
  static const String appName = 'دنيا السعيد';
  static const String appSubtitle = 'تصاميم مطابخ الألمنيوم المصرية';
  static const String appVersion = '1.0.0';

  // API URLs (يمكن تغييرها لاحقاً)
  static const String baseUrl = 'https://api.donia-al-saeed.com/api';
  static const String apiVersion = 'v1';

  // Storage Keys
  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';
  static const String languageKey = 'language';
  static const String themeKey = 'theme_mode';

  // App Colors
  static const int primaryColorValue = 0xFF1E3B8A; // Royal Blue
  static const int secondaryColorValue = 0xFFD4AF37; // Gold
  static const int backgroundColorLight = 0xFFF6F6F8;
  static const int backgroundColorDark = 0xFF121620;

  // Dimensions
  static const double defaultPadding = 16.0;
  static const double defaultBorderRadius = 8.0;
  static const double cardBorderRadius = 12.0;

  // Animation Durations
  static const Duration defaultAnimationDuration = Duration(milliseconds: 300);
  static const Duration splashDuration = Duration(seconds: 3);

  // Images
  static const String logoPath = 'assets/images/logo.png';
  static const String splashImagePath = 'assets/images/splash.png';

  // Contact Info - دنيا السعيد لمطابخ الألمنيوم
  static const String ownerName = 'أحمد سعيد';
  static const String phoneNumber = '771700719';
  static const String phoneNumber2 = '780948255'; // المهندس ضياء
  static const String email = 'info@donia-al-saeed.com';
  static const String address = 'شارع المعرض الرئيسي، مبني 16، القاهرة الجديدة';
  static const double latitude = 30.0131;
  static const double longitude = 31.4261;

  // Social Media
  static const String facebookUrl = 'https://facebook.com/donia-al-saeed';
  static const String instagramUrl = 'https://instagram.com/donia-al-saeed';
  static const String twitterUrl = 'https://twitter.com/donia-al-saeed';
}
