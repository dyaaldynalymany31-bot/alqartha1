import 'package:get/get.dart';
import '../../features/auth/presentation/pages/splash_page.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/signup_page.dart';
import '../../features/home/presentation/pages/home_page.dart';
import '../../features/designs/presentation/pages/designs_gallery_page.dart';
import '../../features/designs/presentation/pages/design_details_page.dart';
import '../../features/orders/presentation/pages/orders_tracking_page.dart';
import '../../features/orders/presentation/pages/custom_order_request_page.dart';
import '../../features/orders/presentation/pages/customer_statement_page.dart';
import '../../features/profile/presentation/pages/user_profile_page.dart';
import '../../features/profile/presentation/pages/about_app_page.dart';
import '../../features/profile/presentation/pages/contact_us_page.dart';
import '../../features/3d/presentation/pages/kitchen_3d_viewer_page.dart';
import '../../features/ar/presentation/pages/ar_try_on_page.dart';
import '../../features/measurements/presentation/pages/advanced_measurement_page.dart';

class AppRouter {
  // Routes
  static const String splash = '/';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String home = '/home';
  static const String designsGallery = '/designs-gallery';
  static const String designDetails = '/design-details';
  static const String ordersTracking = '/orders-tracking';
  static const String customOrderRequest = '/custom-order-request';
  static const String customerStatement = '/customer-statement';
  static const String userProfile = '/user-profile';
  static const String aboutApp = '/about-app';
  static const String contactUs = '/contact-us';
  static const String kitchen3dViewer = '/kitchen-3d-viewer';
  static const String arTryOn = '/ar-try-on';
  static const String advancedMeasurement = '/advanced-measurement';

  // Get Pages Routes
  static List<GetPage> get routes => [
    GetPage(
      name: splash,
      page: () => const SplashPage(),
    ),
    GetPage(
      name: login,
      page: () => const LoginPage(),
    ),
    GetPage(
      name: signup,
      page: () => const SignUpPage(),
    ),
    GetPage(
      name: home,
      page: () => const HomePage(),
    ),
    GetPage(
      name: designsGallery,
      page: () => const DesignsGalleryPage(),
    ),
    GetPage(
      name: designDetails,
      page: () => const DesignDetailsPage(),
    ),
    GetPage(
      name: ordersTracking,
      page: () => const OrdersTrackingPage(),
    ),
    GetPage(
      name: customOrderRequest,
      page: () => const CustomOrderRequestPage(),
    ),
    GetPage(
      name: customerStatement,
      page: () => const CustomerStatementPage(),
    ),
    GetPage(
      name: userProfile,
      page: () => const UserProfilePage(),
    ),
    GetPage(
      name: aboutApp,
      page: () => const AboutAppPage(),
    ),
    GetPage(
      name: contactUs,
      page: () => const ContactUsPage(),
    ),
    GetPage(
      name: kitchen3dViewer,
      page: () => const Kitchen3dViewerPage(),
    ),
    GetPage(
      name: arTryOn,
      page: () => const ArTryOnPage(),
    ),
    GetPage(
      name: advancedMeasurement,
      page: () => const AdvancedMeasurementPage(),
    ),
  ];
}
