import 'package:intl/intl.dart';

class Helpers {
  static String formatCurrency(double amount, {String currency = 'جنيه'}) {
    final formatter = NumberFormat('#,###');
    return '${formatter.format(amount)} $currency';
  }

  static String formatDate(DateTime date) {
    return DateFormat('yyyy-MM-dd', 'ar').format(date);
  }

  static String formatDateTime(DateTime date) {
    return DateFormat('yyyy-MM-dd HH:mm', 'ar').format(date);
  }

  static String getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return 'صباح الخير';
    } else if (hour < 18) {
      return 'مساء الخير';
    } else {
      return 'مساء الخير';
    }
  }
}
