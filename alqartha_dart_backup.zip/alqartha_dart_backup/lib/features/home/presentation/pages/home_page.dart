import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/routes/app_router.dart';
import '../../../../core/services/auth_service.dart';
import '../../../designs/presentation/pages/designs_gallery_page.dart';
import '../../../orders/presentation/pages/orders_tracking_page.dart';
import '../../../profile/presentation/pages/user_profile_page.dart';
import '../widgets/special_offer_banner.dart';
import '../widgets/service_card.dart';
import '../widgets/collection_item.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final authService = Get.find<AuthService>();
    final userName = authService.currentUser?.name ?? 'المستخدم';

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          _buildHomeContent(userName),
          const DesignsGalleryPage(),
          const OrdersTrackingPage(),
          const UserProfilePage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() => _currentIndex = index);
        },
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.grid_view_outlined),
            activeIcon: Icon(Icons.grid_view),
            label: 'التصاميم',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_bag_outlined),
            activeIcon: Icon(Icons.shopping_bag),
            label: 'الطلبات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'الملف الشخصي',
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent(String userName) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.search, size: 24),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                userName,
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Special Offer Banner
            const SpecialOfferBanner(),
            const SizedBox(height: 24),
            // Services Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'الخدمات',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  ServiceCard(
                    title: 'جرب في المنزل',
                    subtitle: 'تصور مطبخك في 3D',
                    icon: Icons.view_in_ar,
                    onTap: () => Get.toNamed(AppRouter.kitchen3dViewer),
                  ),
                  const SizedBox(height: 12),
                  ServiceCard(
                    title: 'طلب تصميم مخصص',
                    subtitle: 'صمم مطبخك حسب رغبتك',
                    icon: Icons.design_services,
                    onTap: () => Get.toNamed(AppRouter.customOrderRequest),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Latest Collections
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'أحدث المجموعات',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      TextButton(
                        onPressed: () => setState(() => _currentIndex = 1),
                        child: const Text('عرض الكل'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 200,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        return CollectionItem(
                          title: 'Modern Aluminum ${index + 1}',
                          imageUrl: 'https://via.placeholder.com/200',
                          onTap: () => Get.toNamed(AppRouter.designDetails),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
