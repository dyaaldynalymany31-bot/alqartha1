class UserModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final int loyaltyPoints;
  final String loyaltyTier;
  final String? imageUrl;
  final String role; // 'admin' or 'user'

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.loyaltyPoints,
    required this.loyaltyTier,
    this.imageUrl,
    this.role = 'user',
  });

  bool get isAdmin => role == 'admin';

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'loyaltyPoints': loyaltyPoints,
      'loyaltyTier': loyaltyTier,
      'imageUrl': imageUrl,
      'role': role,
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      loyaltyPoints: json['loyaltyPoints'] ?? 0,
      loyaltyTier: json['loyaltyTier'] ?? 'Bronze',
      imageUrl: json['imageUrl'],
      role: json['role'] ?? 'user',
    );
  }
}
