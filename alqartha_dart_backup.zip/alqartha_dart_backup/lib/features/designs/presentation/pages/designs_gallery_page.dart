import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/routes/app_router.dart';
import '../widgets/design_card.dart';

class DesignsGalleryPage extends StatefulWidget {
  const DesignsGalleryPage({super.key});

  @override
  State<DesignsGalleryPage> createState() => _DesignsGalleryPageState();
}

class _DesignsGalleryPageState extends State<DesignsGalleryPage> {
  String _selectedFilter = 'الكل';

  final List<String> _filters = ['الكل', 'Modern', 'Classic', 'L-Shape'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('معرض التصاميم'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث عن تصميم...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          // Filter Chips
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _filters.length,
              itemBuilder: (context, index) {
                final filter = _filters[index];
                final isSelected = _selectedFilter == filter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() => _selectedFilter = filter);
                    },
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          // Designs Grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 0.75,
              ),
              itemCount: 10,
              itemBuilder: (context, index) {
                return DesignCard(
                  title: 'Modern Aluminum ${index + 1}',
                  imageUrl: 'https://via.placeholder.com/300',
                  onTap: () => Get.toNamed(AppRouter.designDetails),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
