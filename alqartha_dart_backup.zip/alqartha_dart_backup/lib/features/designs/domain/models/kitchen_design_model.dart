class KitchenDesignModel {
  final String id;
  final String title;
  final String description;
  final String imageUrl;
  final String category; // Modern, Classic, L-Shape, etc.
  final double pricePerSquareMeter;
  final List<String> features;
  final List<ColorOption> colorOptions;
  final double rating;
  final int reviewCount;

  KitchenDesignModel({
    required this.id,
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.category,
    required this.pricePerSquareMeter,
    required this.features,
    required this.colorOptions,
    this.rating = 0.0,
    this.reviewCount = 0,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'imageUrl': imageUrl,
      'category': category,
      'pricePerSquareMeter': pricePerSquareMeter,
      'features': features,
      'colorOptions': colorOptions.map((e) => e.toJson()).toList(),
      'rating': rating,
      'reviewCount': reviewCount,
    };
  }

  factory KitchenDesignModel.fromJson(Map<String, dynamic> json) {
    return KitchenDesignModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
      category: json['category'] ?? '',
      pricePerSquareMeter: (json['pricePerSquareMeter'] ?? 0).toDouble(),
      features: List<String>.from(json['features'] ?? []),
      colorOptions: (json['colorOptions'] as List?)
          ?.map((e) => ColorOption.fromJson(e))
          .toList() ?? [],
      rating: (json['rating'] ?? 0).toDouble(),
      reviewCount: json['reviewCount'] ?? 0,
    );
  }
}

class ColorOption {
  final String name;
  final String colorCode;
  final String imageUrl;

  ColorOption({
    required this.name,
    required this.colorCode,
    required this.imageUrl,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'colorCode': colorCode,
      'imageUrl': imageUrl,
    };
  }

  factory ColorOption.fromJson(Map<String, dynamic> json) {
    return ColorOption(
      name: json['name'] ?? '',
      colorCode: json['colorCode'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
    );
  }
}
