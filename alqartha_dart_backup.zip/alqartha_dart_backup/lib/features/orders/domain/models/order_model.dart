enum OrderStatus {
  confirmed,
  manufacturing,
  qualityCheck,
  outForDelivery,
  delivered,
  cancelled,
}

class OrderModel {
  final String id;
  final String designId;
  final String designTitle;
  final String designImageUrl;
  final double totalPrice;
  final double paidAmount;
  final double remainingBalance;
  final OrderStatus status;
  final DateTime orderDate;
  final DateTime? estimatedDeliveryDate;
  final List<TransactionModel> transactions;
  final Map<String, dynamic>? dimensions;

  OrderModel({
    required this.id,
    required this.designId,
    required this.designTitle,
    required this.designImageUrl,
    required this.totalPrice,
    required this.paidAmount,
    required this.remainingBalance,
    required this.status,
    required this.orderDate,
    this.estimatedDeliveryDate,
    required this.transactions,
    this.dimensions,
  });

  String get statusText {
    switch (status) {
      case OrderStatus.confirmed:
        return 'تم التأكيد';
      case OrderStatus.manufacturing:
        return 'قيد التصنيع';
      case OrderStatus.qualityCheck:
        return 'فحص الجودة';
      case OrderStatus.outForDelivery:
        return 'قيد التوصيل';
      case OrderStatus.delivered:
        return 'تم التسليم';
      case OrderStatus.cancelled:
        return 'ملغي';
    }
  }

  double get progressPercentage {
    switch (status) {
      case OrderStatus.confirmed:
        return 0.25;
      case OrderStatus.manufacturing:
        return 0.5;
      case OrderStatus.qualityCheck:
        return 0.75;
      case OrderStatus.outForDelivery:
        return 0.9;
      case OrderStatus.delivered:
        return 1.0;
      case OrderStatus.cancelled:
        return 0.0;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'designId': designId,
      'designTitle': designTitle,
      'designImageUrl': designImageUrl,
      'totalPrice': totalPrice,
      'paidAmount': paidAmount,
      'remainingBalance': remainingBalance,
      'status': status.toString(),
      'orderDate': orderDate.toIso8601String(),
      'estimatedDeliveryDate': estimatedDeliveryDate?.toIso8601String(),
      'transactions': transactions.map((e) => e.toJson()).toList(),
      'dimensions': dimensions,
    };
  }

  factory OrderModel.fromJson(Map<String, dynamic> json) {
    return OrderModel(
      id: json['id'] ?? '',
      designId: json['designId'] ?? '',
      designTitle: json['designTitle'] ?? '',
      designImageUrl: json['designImageUrl'] ?? '',
      totalPrice: (json['totalPrice'] ?? 0).toDouble(),
      paidAmount: (json['paidAmount'] ?? 0).toDouble(),
      remainingBalance: (json['remainingBalance'] ?? 0).toDouble(),
      status: _parseStatus(json['status']),
      orderDate: DateTime.parse(json['orderDate']),
      estimatedDeliveryDate: json['estimatedDeliveryDate'] != null
          ? DateTime.parse(json['estimatedDeliveryDate'])
          : null,
      transactions: (json['transactions'] as List?)
          ?.map((e) => TransactionModel.fromJson(e))
          .toList() ?? [],
      dimensions: json['dimensions'],
    );
  }

  static OrderStatus _parseStatus(String? status) {
    switch (status) {
      case 'OrderStatus.confirmed':
        return OrderStatus.confirmed;
      case 'OrderStatus.manufacturing':
        return OrderStatus.manufacturing;
      case 'OrderStatus.qualityCheck':
        return OrderStatus.qualityCheck;
      case 'OrderStatus.outForDelivery':
        return OrderStatus.outForDelivery;
      case 'OrderStatus.delivered':
        return OrderStatus.delivered;
      case 'OrderStatus.cancelled':
        return OrderStatus.cancelled;
      default:
        return OrderStatus.confirmed;
    }
  }
}

class TransactionModel {
  final String id;
  final String description;
  final double amount;
  final DateTime date;
  final String type; // payment, purchase, refund

  TransactionModel({
    required this.id,
    required this.description,
    required this.amount,
    required this.date,
    required this.type,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'description': description,
      'amount': amount,
      'date': date.toIso8601String(),
      'type': type,
    };
  }

  factory TransactionModel.fromJson(Map<String, dynamic> json) {
    return TransactionModel(
      id: json['id'] ?? '',
      description: json['description'] ?? '',
      amount: (json['amount'] ?? 0).toDouble(),
      date: DateTime.parse(json['date']),
      type: json['type'] ?? '',
    );
  }
}
