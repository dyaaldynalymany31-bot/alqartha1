import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TransactionItem extends StatelessWidget {
  final String description;
  final double amount;
  final DateTime date;

  const TransactionItem({
    super.key,
    required this.description,
    required this.amount,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.blue.shade100,
          child: const Icon(Icons.payment, color: Colors.blue),
        ),
        title: Text(description),
        subtitle: Text(DateFormat('yyyy-MM-dd').format(date)),
        trailing: Text(
          '${amount.toStringAsFixed(0)} ريال',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.green,
          ),
        ),
      ),
    );
  }
}
