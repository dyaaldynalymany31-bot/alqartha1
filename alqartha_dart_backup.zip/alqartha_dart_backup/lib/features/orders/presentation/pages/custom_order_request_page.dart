import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomOrderRequestPage extends StatefulWidget {
  const CustomOrderRequestPage({super.key});

  @override
  State<CustomOrderRequestPage> createState() => _CustomOrderRequestPageState();
}

class _CustomOrderRequestPageState extends State<CustomOrderRequestPage> {
  int _currentStep = 0;
  final _lengthController = TextEditingController();
  final _widthController = TextEditingController();
  String _selectedLayout = 'L-Shape';

  @override
  void dispose() {
    _lengthController.dispose();
    _widthController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('طلب تصميم مخصص'),
      ),
      body: Stepper(
        currentStep: _currentStep,
        onStepContinue: () {
          if (_currentStep < 2) {
            setState(() => _currentStep++);
          } else {
            // Submit order
            Get.snackbar('نجح', 'تم إرسال طلبك بنجاح');
          }
        },
        onStepCancel: () {
          if (_currentStep > 0) {
            setState(() => _currentStep--);
          }
        },
        steps: [
          Step(
            title: const Text('الخطوة 1 من 3'),
            subtitle: const Text('الأبعاد والتفضيلات'),
            isActive: _currentStep >= 0,
            state: _currentStep > 0 ? StepState.complete : StepState.indexed,
            content: Column(
              children: [
                // AI Tool Section
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Text('ميزة جديدة: تحتاج مساعدة في القياس؟'),
                        const SizedBox(height: 12),
                        Image.network(
                          'https://via.placeholder.com/200',
                          height: 150,
                          fit: BoxFit.cover,
                        ),
                        const SizedBox(height: 12),
                        ElevatedButton(
                          onPressed: () {},
                          child: const Text('فتح أداة AI'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                // Room Dimensions
                TextField(
                  controller: _lengthController,
                  decoration: const InputDecoration(
                    labelText: 'الطول (متر)',
                    prefixIcon: Icon(Icons.straighten),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _widthController,
                  decoration: const InputDecoration(
                    labelText: 'العرض (متر)',
                    prefixIcon: Icon(Icons.straighten),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 24),
                // Kitchen Layout
                const Text('تخطيط المطبخ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: ['L-Shape', 'Island', 'U-Shape', 'Straight'].map((layout) {
                    return ChoiceChip(
                      label: Text(layout),
                      selected: _selectedLayout == layout,
                      onSelected: (selected) {
                        setState(() => _selectedLayout = layout);
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 24),
                // Preferences
                const Text('التفضيلات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: ['Matte', 'Glossy', 'Natural', 'Wood Look'].map((pref) {
                    return FilterChip(
                      label: Text(pref),
                      onSelected: (selected) {},
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          Step(
            title: const Text('الخطوة 2 من 3'),
            subtitle: const Text('التفاصيل الإضافية'),
            isActive: _currentStep >= 1,
            state: _currentStep > 1 ? StepState.complete : StepState.indexed,
            content: const Column(
              children: [
                Text('محتوى الخطوة 2'),
              ],
            ),
          ),
          Step(
            title: const Text('الخطوة 3 من 3'),
            subtitle: const Text('المراجعة والإرسال'),
            isActive: _currentStep >= 2,
            content: const Column(
              children: [
                Text('محتوى الخطوة 3'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
