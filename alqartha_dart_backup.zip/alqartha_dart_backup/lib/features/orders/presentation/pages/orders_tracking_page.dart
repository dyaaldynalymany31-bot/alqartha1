import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/routes/app_router.dart';
import '../widgets/order_card.dart';

class OrdersTrackingPage extends StatefulWidget {
  const OrdersTrackingPage({super.key});

  @override
  State<OrdersTrackingPage> createState() => _OrdersTrackingPageState();
}

class _OrdersTrackingPageState extends State<OrdersTrackingPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تتبع طلباتك'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'الطلبات النشطة'),
            Tab(text: 'سجل الطلبات'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Active Orders
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              OrderCard(
                orderId: 'ORD-001',
                title: 'L-Shape Matte Finish Kitchen',
                imageUrl: 'https://via.placeholder.com/200',
                status: 'قيد التصنيع',
                progress: 0.5,
                onTap: () => Get.toNamed(AppRouter.customerStatement),
              ),
              const SizedBox(height: 12),
              OrderCard(
                orderId: 'ORD-002',
                title: 'Modern Aluminum Kitchen',
                imageUrl: 'https://via.placeholder.com/200',
                status: 'تم التأكيد',
                progress: 0.25,
                onTap: () => Get.toNamed(AppRouter.customerStatement),
              ),
            ],
          ),
          // Order History
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              OrderCard(
                orderId: 'ORD-003',
                title: 'Classic Wood Oak Kitchen',
                imageUrl: 'https://via.placeholder.com/200',
                status: 'تم التسليم',
                progress: 1.0,
                onTap: () => Get.toNamed(AppRouter.customerStatement),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.toNamed(AppRouter.customOrderRequest),
        icon: const Icon(Icons.add),
        label: const Text('طلب جديد'),
      ),
    );
  }
}
