import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';

class ContactUsPage extends StatelessWidget {
  const ContactUsPage({super.key});

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final uri = Uri.parse('tel:$phoneNumber');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('اتصل بنا'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Kitchen Image
            Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey[200],
              ),
              child: Image.network(
                'https://via.placeholder.com/400',
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Company Info
                  Text(
                    AppConstants.appSubtitle,
                    style: Theme.of(context).textTheme.titleLarge,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                  // Address
                  _buildContactItem(
                    context,
                    icon: Icons.location_on,
                    title: 'العنوان',
                    subtitle: AppConstants.address,
                    onTap: () {
                      // Open map
                      _launchUrl(
                        'https://www.google.com/maps/search/?api=1&query=${AppConstants.latitude},${AppConstants.longitude}',
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  // Phone
                  _buildContactItem(
                    context,
                    icon: Icons.phone,
                    title: 'الهاتف',
                    subtitle: AppConstants.phoneNumber,
                    onTap: () => _makePhoneCall(AppConstants.phoneNumber),
                  ),
                  const SizedBox(height: 16),
                  // Email
                  _buildContactItem(
                    context,
                    icon: Icons.email,
                    title: 'البريد الإلكتروني',
                    subtitle: AppConstants.email,
                    onTap: () => _launchUrl('mailto:${AppConstants.email}'),
                  ),
                  const SizedBox(height: 32),
                  // Location Button
                  ElevatedButton.icon(
                    onPressed: () {
                      _launchUrl(
                        'https://www.google.com/maps/search/?api=1&query=${AppConstants.latitude},${AppConstants.longitude}',
                      );
                    },
                    icon: const Icon(Icons.map),
                    label: const Text('موقعنا'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      minimumSize: const Size(double.infinity, 50),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: AppTheme.primaryColor.withOpacity(0.1),
          child: Icon(icon, color: AppTheme.primaryColor),
        ),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}
