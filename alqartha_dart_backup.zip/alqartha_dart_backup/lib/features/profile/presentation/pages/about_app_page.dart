import 'package:flutter/material.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';

class AboutAppPage extends StatelessWidget {
  const AboutAppPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('حول التطبيق'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Logo Section
            Container(
              padding: const EdgeInsets.all(32),
              child: Column(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Icon(
                      Icons.kitchen,
                      size: 50,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    AppConstants.appName,
                    style: Theme.of(context).textTheme.displaySmall,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'تصاميم الألمنيوم',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            // Content Sections
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSection(
                    context,
                    title: 'من نحن',
                    content:
                        'نحن شركة رائدة في مجال تصاميم مطابخ الألمنيوم في مصر. نقدم حلولاً مبتكرة وعصرية لتحويل مطابخك إلى مساحات جميلة وعملية.',
                  ),
                  const SizedBox(height: 32),
                  _buildSection(
                    context,
                    title: 'مهمتنا',
                    content:
                        'تقديم أفضل تصاميم مطابخ الألمنيوم بجودة عالية وأسعار منافسة، مع التركيز على رضا العملاء والابتكار في التصميم.',
                  ),
                  const SizedBox(height: 32),
                  _buildSection(
                    context,
                    title: 'الجودة المميزة',
                    content:
                        'نستخدم أحدث التقنيات والمواد عالية الجودة لضمان متانة وجمال تصميماتنا. كل مطبخ مصمم خصيصاً ليلبي احتياجاتك وتطلعاتك.',
                  ),
                  const SizedBox(height: 32),
                  // App Version
                  Center(
                    child: Text(
                      'الإصدار ${AppConstants.appVersion}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.grey[500],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(
    BuildContext context, {
    required String title,
    required String content,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          content,
          style: Theme.of(context).textTheme.bodyLarge,
          textAlign: TextAlign.justify,
        ),
      ],
    );
  }
}
