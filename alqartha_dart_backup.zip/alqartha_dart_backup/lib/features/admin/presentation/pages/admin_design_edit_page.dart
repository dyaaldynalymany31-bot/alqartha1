import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'admin_design_add_page.dart';

class AdminDesignEditPage extends StatelessWidget {
  const AdminDesignEditPage({super.key});

  @override
  Widget build(BuildContext context) {
    final args = Get.arguments as Map<String, dynamic>?;
    final designId = args?['id'] ?? '';

    // Reuse the add page with pre-filled data
    return AdminDesignAddPage();
  }
}
