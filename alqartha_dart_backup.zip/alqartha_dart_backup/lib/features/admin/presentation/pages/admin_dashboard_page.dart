import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/routes/app_router.dart';
import '../../../../core/services/auth_service.dart';
import '../widgets/admin_stat_card.dart';
import '../widgets/admin_quick_action_card.dart';

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = Get.find<AuthService>();
    final userName = authService.currentUser?.name ?? 'المشرف';

    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await authService.logout();
              Get.offAllNamed(AppRouter.login);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppTheme.primaryColor, AppTheme.primaryColor.withOpacity(0.8)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'مرحباً $userName',
                    style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'إدارة متجر دنيا السعيد لمطابخ الألمنيوم',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Statistics Cards
            Text(
              'الإحصائيات',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.5,
              children: [
                AdminStatCard(
                  title: 'الطلبات',
                  value: '47',
                  icon: Icons.shopping_bag,
                  color: AppTheme.primaryColor,
                  onTap: () => Get.toNamed(AppRouter.adminOrders),
                ),
                AdminStatCard(
                  title: 'العملاء',
                  value: '128',
                  icon: Icons.people,
                  color: Colors.green,
                  onTap: () => Get.toNamed(AppRouter.adminCustomers),
                ),
                AdminStatCard(
                  title: 'التصاميم',
                  value: '32',
                  icon: Icons.design_services,
                  color: AppTheme.secondaryColor,
                  onTap: () => Get.toNamed(AppRouter.adminDesigns),
                ),
                AdminStatCard(
                  title: 'الإيرادات',
                  value: '125,000',
                  icon: Icons.attach_money,
                  color: Colors.orange,
                  onTap: () => Get.toNamed(AppRouter.adminReports),
                ),
              ],
            ),
            const SizedBox(height: 24),
            // Quick Actions
            Text(
              'إجراءات سريعة',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            AdminQuickActionCard(
              title: 'إضافة تصميم جديد',
              icon: Icons.add_photo_alternate,
              color: AppTheme.primaryColor,
              onTap: () => Get.toNamed(AppRouter.adminDesigns, arguments: {'action': 'add'}),
            ),
            const SizedBox(height: 12),
            AdminQuickActionCard(
              title: 'عرض التقارير',
              icon: Icons.analytics,
              color: Colors.blue,
              onTap: () => Get.toNamed(AppRouter.adminReports),
            ),
            const SizedBox(height: 12),
            AdminQuickActionCard(
              title: 'إدارة الطلبات',
              icon: Icons.inventory_2,
              color: Colors.green,
              onTap: () => Get.toNamed(AppRouter.adminOrders),
            ),
            const SizedBox(height: 12),
            AdminQuickActionCard(
              title: 'قائمة العملاء',
              icon: Icons.people_outline,
              color: Colors.purple,
              onTap: () => Get.toNamed(AppRouter.adminCustomers),
            ),
          ],
        ),
      ),
    );
  }
}
