import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';

class AdminFloatingActionButton extends StatelessWidget {
  final VoidCallback onPressed;

  const AdminFloatingActionButton({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: onPressed,
      backgroundColor: AppTheme.primaryColor,
      icon: const Icon(Icons.add, color: Colors.white),
      label: const Text(
        'إضافة تصميم',
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
    );
  }
}
