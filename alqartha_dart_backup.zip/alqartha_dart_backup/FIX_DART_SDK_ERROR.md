# حل مشكلة Dart SDK المقفل

## 🔴 المشكلة
```
Error: Unable to update Dart SDK
The process cannot access the file because it is being used by another process
```

## ✅ الحل السريع (اتبع بالترتيب)

### الخطوة 1: أغلق كل شيء
1. أغلق **VS Code** تماماً
2. أغلق **Android Studio** إذا كان مفتوحاً
3. أغلق **جميع نوافذ PowerShell/Terminal**
4. اضغط `Ctrl + Shift + Esc` لفتح Task Manager
5. ابحث عن أي عملية باسم `dart` أو `flutter` وأغلقها

### الخطوة 2: انتظر 10 ثوانٍ
دع النظام يحرر الملفات

### الخطوة 3: افتح VS Code فقط
1. افتح **VS Code** (فقط)
2. `File > Open Folder`
3. اختر مجلد المشروع
4. افتح Terminal (`Ctrl + ~`)

### الخطوة 4: نفذ الأوامر

```bash
# 1. تنظيف
flutter clean

# 2. تثبيت التبعيات
flutter pub get

# 3. تفعيل Windows
flutter config --enable-windows-desktop

# 4. تشغيل
flutter run -d windows
```

---

## 🔧 إذا استمرت المشكلة

### الحل البديل 1: إعادة تشغيل الكمبيوتر

أسهل حل:
1. أعد تشغيل الكمبيوتر
2. افتح VS Code مباشرة
3. افتح المشروع
4. نفذ الأوامر

### الحل البديل 2: حذف الـ Cache يدوياً

**⚠️ احترس: أغلق كل شيء أولاً**

```powershell
# في PowerShell كـ Administrator
cd C:\flutter\flutter_windows_3.38.1-stable\flutter

# حذف الـ cache
Remove-Item -Recurse -Force .\bin\cache\dart-sdk
Remove-Item -Recurse -Force .\bin\cache\artifacts

# الآن نفذ
flutter doctor
```

### الحل البديل 3: تحديث Flutter

```bash
# في VS Code Terminal
flutter upgrade
```

---

## 🎯 الطريقة الصحيحة للعمل

### لتجنب المشكلة مستقبلاً:

1. **استخدم VS Code فقط** - لا تفتح عدة برامج معاً
2. **نافذة Terminal واحدة** - لا تفتح عدة نوافذ
3. **أغلق Terminal قبل إغلاق VS Code**
4. **لا تشغل عدة مشاريع Flutter** في نفس الوقت

---

## 📱 تشغيل المشروع بدون مشاكل

### في VS Code:

```bash
# 1. تنظيف (إذا كان هناك مشاكل)
flutter clean

# 2. تثبيت
flutter pub get

# 3. تشغيل على Windows
flutter run -d windows
```

### بناء APK (بدلاً من التشغيل المباشر):

**لا تبني APK إلا بعد التأكد من أن المشروع يعمل!**

```bash
# أولاً: تأكد أن المشروع يعمل
flutter run -d windows

# إذا عمل بنجاح، يمكنك بناء APK:
flutter build apk --release
```

---

## ⚡ الحل الفوري الآن

**افعل هذا الآن:**

1. اضغط `Alt + F4` لإغلاق كل النوافذ المفتوحة
2. انتظر 10 ثوانٍ
3. افتح VS Code فقط
4. افتح المشروع
5. افتح Terminal
6. نفذ:

```bash
flutter pub get
flutter run -d windows
```

---

## 🔍 التحقق من المشكلة

لمعرفة من يستخدم الملف:

```powershell
# في PowerShell
Get-Process | Where-Object {$_.ProcessName -like "*dart*" -or $_.ProcessName -like "*flutter*"}
```

إذا ظهرت عمليات، أغلقها من Task Manager.

---

## ✅ بعد الحل

عندما تنجح الأوامر، سترى:

```
Running "flutter pub get" in donia_al_saeed...
✓ packages get completed
```

الآن يمكنك تشغيل التطبيق:

```bash
flutter run -d windows
```

---

**ملاحظة مهمة:** لا تستخدم PowerShell خارج VS Code. استخدم Terminal داخل VS Code فقط.
