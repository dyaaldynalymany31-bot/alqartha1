# 🚀 ابدأ من هنا - تشغيل المشروع

## ⚠️ مهم جداً: استخدم VS Code

PowerShell لا يعمل بشكل جيد مع المسارات العربية. استخدم VS Code بدلاً منه.

---

## 📋 الخطوات بالترتيب (اتبعها بالضبط)

### الخطوة 1: افتح المشروع في VS Code

1. افتح **VS Code**
2. اضغط `File` → `Open Folder`
3. اختر المجلد: `C:\Users\nathe\OneDrive\Desktop\واجهات فلاتر للمحل`
4. اضغط `Select Folder`

### الخطوة 2: افتح Terminal في VS Code

اضغط `Ctrl + ~` (أو من القائمة: `Terminal` → `New Terminal`)

### الخطوة 3: نفذ هذه الأوامر بالترتيب

**في Terminal داخل VS Code، انسخ والصق هذه الأوامر واحداً تلو الآخر:**

```bash
# 1. تنظيف المشروع
flutter clean
```

انتظر حتى ينتهي، ثم:

```bash
# 2. تثبيت التبعيات
flutter pub get
```

انتظر حتى ينتهي، ثم:

```bash
# 3. تفعيل Windows Desktop
flutter config --enable-windows-desktop
```

ثم:

```bash
# 4. التحقق من الإعداد
flutter doctor
```

وأخيراً:

```bash
# 5. تشغيل التطبيق على Windows
flutter run -d windows
```

---

## ✅ النتيجة المتوقعة

بعد `flutter run -d windows`:
- ستفتح نافذة التطبيق
- ستظهر شاشة زرقاء (Splash Screen)
- بعد 3 ثوانٍ، ستظهر شاشة تسجيل الدخول
- يمكنك الدخول بأي بيانات (مثلاً: `test@test.com` / `123456`)

---

## 🎯 إذا ظهرت مشكلة "No devices"

### الحل للتشغيل على Android:

1. افتح **Android Studio**
2. اذهب إلى `Tools` → `Device Manager`
3. اضغط `Create Device`
4. اختر `Pixel 5` → `Next`
5. اختر نظام Android (مثل `R` أو `S`) → `Next` → `Finish`
6. شغّل الـ Emulator (اضغط زر ▶️ بجانب الجهاز)
7. ارجع لـ VS Code ونفذ:
```bash
flutter run
```

---

## 🔧 إذا فشل flutter pub get

في VS Code Terminal:

```bash
# احذف ملف pubspec.lock
Remove-Item pubspec.lock

# ثم أعد المحاولة
flutter pub get
```

إذا استمرت المشكلة:

```bash
flutter pub cache clean
flutter pub get
```

---

## 📝 ملاحظات مهمة

✅ **تم حل المشاكل التالية:**
- إزالة مكتبة `flutter_gl` (كانت تسبب مشاكل)
- إصلاح Android v1 embedding
- إضافة ملفات Windows المطلوبة

✅ **المشروع جاهز للعمل على:**
- Windows Desktop ✅
- Android ✅ (بعد تشغيل Emulator)

✅ **لا تحتاج:**
- ملفات خطوط إضافية (يستخدم Google Fonts)
- API حقيقي (يعمل بـ Mock Data)

---

## 🎨 ما يمكنك فعله في التطبيق

بعد تسجيل الدخول:
- تصفح معرض التصاميم
- عرض تفاصيل التصميم
- تتبع الطلبات
- طلب تصميم مخصص
- عرض كشف العميل
- الملف الشخصي
- اتصل بنا
- حول التطبيق

---

## 🚨 الأوامر الأساسية السريعة

```bash
# التشغيل
flutter run -d windows

# التشغيل على Android
flutter run

# عرض الأجهزة المتاحة
flutter devices

# إيقاف التطبيق
اضغط 'q' في Terminal

# Hot Reload (بعد تغيير الكود)
اضغط 'r' في Terminal
```

---

## ✨ جاهز!

المشروع كامل وجاهز للتشغيل. اتبع الخطوات أعلاه في VS Code.

**إذا واجهت أي مشكلة، راجع ملف `COMPLETE_SETUP_GUIDE.md`**
